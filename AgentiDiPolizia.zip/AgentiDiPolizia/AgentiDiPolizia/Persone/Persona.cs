﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AgentiDiPolizia.Persone
{
    public abstract class Persona
    {
        //è una classe e non un'interfaccia perchè deve implementare dei metodi
        public string Nome { get; set; }
        public string Cognome { get; set; }
        public string CodiceFiscale { get; set; }

        //Metodi

        //Ridefinisco equals perchè due persone sono uguali se hanno lo stesso codice fiscale
        public override bool Equals(object obj)
        {
            return obj is Persona persona &&
                CodiceFiscale == persona.CodiceFiscale;
        }

        //Se implemento Equals devo implementare anche operator == e operator !=
        public static bool operator ==(Persona dx, Persona sx)
        {
            return Equals(dx, sx);
        }

        public static bool operator !=(Persona dx, Persona sx)
        {
            return !(dx == sx);
        }


    }
}
