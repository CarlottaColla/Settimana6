﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace AgentiDiPolizia.Agenti
{
    public static class SqlDataReaderExtension
    {
        //Estendo il comportamento del dataReader per poter utilizzare il metodo ToString ridefinito in Agente
        public static Agente ToAgente(this SqlDataReader reader)
        {
            return new Agente()
            {
                CodiceFiscale = reader["Codice_fiscalse"].ToString(),
                Nome = reader["Nome"].ToString(),
                Cognome = reader["Cognome"].ToString(),
                AnniDiServizio = (int)reader["Anni_servizio"]
            };
        }
    }
}
