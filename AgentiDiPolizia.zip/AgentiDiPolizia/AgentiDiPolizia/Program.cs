﻿using System;
using AgentiDiPolizia.Agenti;
using AgentiDiPolizia.Menu;

namespace AgentiDiPolizia
{
    class Program
    {
        static void Main(string[] args)
        {
            MenuUtente.MostraMenuUtente();
        }
    }
}
