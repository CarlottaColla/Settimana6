﻿using AgentiDiPolizia.Agenti;
using System;
using System.Collections.Generic;
using System.Text;

namespace AgentiDiPolizia.Menu
{
    public class MenuUtente
    {
        public static void MostraMenuUtente()
        {
            int operazione = 0;
            Console.WriteLine("Benvenuto!");
            do
            {
                Console.WriteLine("Che operazione vuoi eseguire?\n" +
                    "1 - Mostra tutti gli agenti\n" +
                    "2 - Mostrare gli agenti assegnati ad una determinata area\n" +
                    "3 - Mostrare gli agenti con anni di servizio maggiori o uguali rispetto ad un input\n" +
                    "4 - Inserire un nuovo agente\n" +
                    "5 - Esci");
                operazione = Convert.ToInt32(Console.ReadLine());
                switch(operazione)
                {
                    case 1:
                        AgentiModalitaConnessa.TuttiGliAgenti();
                        break;
                    case 2:
                        AgentiModalitaConnessa.TutteLeAree();
                        Console.WriteLine("inserisci l'area: ");
                        string area = Console.ReadLine();
                        AgentiModalitaConnessa.AgenteInUnArea(area);
                        break;
                    case 3:
                        Console.WriteLine("Inserisci gli anni di servizio:");
                        int anni = Convert.ToInt32(Console.ReadLine());
                        AgentiModalitaConnessa.AgentiConAnniDiServizio(anni);
                        break;
                    case 4:
                        Console.WriteLine("Inserisci il nome:");
                        string nome = Console.ReadLine();
                        Console.WriteLine("Inserisci il conome:");
                        string cognome = Console.ReadLine();
                        Console.WriteLine("Inserisci il codice fiscale:");
                        string cf = Console.ReadLine();
                        Console.WriteLine("Inserisci la data di nascita:");
                        DateTime data = Convert.ToDateTime(Console.ReadLine());
                        Console.WriteLine("Inserisci gli anni di servizio:");
                        int anniServizio = Convert.ToInt32(Console.ReadLine());
                        Agente agente = new Agente(nome, cognome, cf, data, anniServizio);
                        AgentiModalitaDisconnessa.InserisciAgente(agente);
                        break;
                    case 5:
                        Console.WriteLine("Arrivederci");
                        break;
                }
                if(operazione <0 || operazione > 5)
                {
                    Console.WriteLine("Operazione non disponibile, scegli un'operazione presente nel menu");
                }
                else
                {
                    Console.WriteLine("Premi un tasto per continuare");
                    Console.ReadKey();
                    Console.Clear();
                }
            } while (operazione != 5);

        }
        
    }
}
