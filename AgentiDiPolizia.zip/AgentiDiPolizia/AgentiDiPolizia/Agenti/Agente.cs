﻿using AgentiDiPolizia.Persone;
using System;
using System.Collections.Generic;
using System.Text;
namespace AgentiDiPolizia.Agenti
{
    public class Agente : Persona
    {
        public DateTime DataNascita{ get; }
        public int AnniDiServizio { get; set; }

        //Ho bisogno di un costruttare per creare un nuovo agente da inserire
        public Agente () { }
        public Agente(string nome, string cognome, string cf, DateTime data, int anni)
        {
            Nome = nome;
            Cognome = cognome;
            CodiceFiscale = cf;
            DataNascita = data;
            AnniDiServizio = anni;
        }

        //Ridefinisco il toString per stampare correttamente
        public override string ToString()
        {
            return CodiceFiscale + " - " + Nome + " " + Cognome + " - " + AnniDiServizio + " anni di servizio";
        }
    }
}
