﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace AgentiDiPolizia.Agenti
{
    public class AgentiModalitaConnessa
    {
        //Stringa di connessione
        const string connectionString = @"Persist Security Info = False; Integrated Security = true; Initial Catalog = POLIZIA; Server = .\SQLEXPRESS";

        //Mostrare tutti gli agenti
        public static void TuttiGliAgenti()
        {
            using(SqlConnection connection = new SqlConnection(connectionString))
            {
                //Apro la connessione
                connection.Open();

                //Creo il comando
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = "SELECT * FROM Agente_Di_Polizia";

                //Eseguo il comando: ho bisogno di un DataReader perchè il comando ritorna una tabella
                SqlDataReader reader = command.ExecuteReader();

                //Leggo i dati mostrandoli a schermo
                while (reader.Read())
                {
                    Console.WriteLine(reader.ToAgente().ToString());
                }

                //Chiudo la connessione
                reader.Close();
                connection.Close();
            }
        }

        //Mostrare gli agente assegnati ad un'area data in input
        public static void AgenteInUnArea (string area)
        {
            using(SqlConnection connection = new SqlConnection(connectionString))
            {
                //Apro la connessione
                connection.Open();

                //Creo il comando
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = "SELECT Agente_di_polizia.* FROM Agente_di_polizia " +
                    "INNER JOIN Assegnazione ON " +
                    "Agente_di_polizia.ID = Assegnazione.ID_agente " +
                    "INNER JOIN Area_metropolitana ON " +
                    "Assegnazione.ID_area = Area_metropolitana.ID " +
                    "WHERE Area_metropolitana.Codice_area = @area";

                //Inserisco il parametro di input
                command.Parameters.AddWithValue("@area", area);

                //Esegue il comando: Ritorna una o più record quindi uso un dataReader
                SqlDataReader reader = command.ExecuteReader();

                //Stampo i risultati
                while (reader.Read())
                {
                    Console.WriteLine(reader.ToAgente().ToString());
                }

                //Chiudo la connessione
                reader.Close();
                connection.Close();
            }
        }

        //Mostrare gli agenti con anni di servizio maggiori o uguali rispetto ad un input
        public static void AgentiConAnniDiServizio(int anniDiServizio)
        {
            using(SqlConnection connection = new SqlConnection(connectionString))
            {
                //Apro la connessione
                connection.Open();

                //Creo il comando
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = "SELECT * FROM Agente_di_polizia WHERE Anni_Servizio >= @anni";

                //Inserisco il parametro di input
                command.Parameters.AddWithValue("@anni", anniDiServizio);

                //Eseguo il comando: uso dataReader perchè il risultato è uno o più record
                SqlDataReader reader = command.ExecuteReader();

                //Stampo i risultati
                while(reader.Read())
                {
                    Console.WriteLine(reader.ToAgente().ToString());
                }

                //Chiudo la connessione
                reader.Close();
                connection.Close();
            }
        }

        //Ho aggiunto questa funzione per mostrare le aree disponibili
        public static void TutteLeAree()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                //Apro la connessione
                connection.Open();

                //Creo il comando
                SqlCommand command = new SqlCommand();
                command.Connection = connection;
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = "SELECT Codice_area FROM Area_metropolitana";

                //Eseguo il comando: ho bisogno di un DataReader perchè il comando può ritornare più record
                SqlDataReader reader = command.ExecuteReader();

                //Leggo i dati mostrandoli a schermo
                Console.WriteLine("Le aree disponibili sono: ");
                while (reader.Read())
                {
                    Console.WriteLine(reader["Codice_area"]);
                }

                //Chiudo la connessione
                reader.Close();
                connection.Close();
            }
        }
    }
}
