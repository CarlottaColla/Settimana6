﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;

namespace AgentiDiPolizia.Agenti
{
    class AgentiModalitaDisconnessa
    {
        //Stringa di connessione
        const string connectionString = @"Persist Security Info = False; Integrated Security = true; Initial Catalog = POLIZIA; Server = .\SQLEXPRESS";
        
        //Inserire un nuovo agente
        public static void InserisciAgente (Agente agente)
        {
            using(SqlConnection connection = new SqlConnection(connectionString))
            {
                //Creo l'adapter
                SqlDataAdapter adapter = new SqlDataAdapter();

                //Creo il metodo select per il fill
                SqlCommand commandSelect = new SqlCommand();
                commandSelect.Connection = connection;
                commandSelect.CommandType = System.Data.CommandType.Text;
                commandSelect.CommandText = "SELECT * FROM Agente_di_polizia";

                //Creo il comando di insert
                SqlCommand commandInsert = new SqlCommand();
                commandInsert.Connection = connection;
                commandInsert.CommandType = System.Data.CommandType.Text;
                commandInsert.CommandText = "INSERT INTO Agente_di_polizia VALUES (@nome, @cognome, @cf, @dataNat, @anniServizio)";

                //Istruisco l'adapter
                commandInsert.Parameters.Add("@nome",System.Data.SqlDbType.NVarChar,30,"Nome");
                commandInsert.Parameters.Add("@cognome", System.Data.SqlDbType.NVarChar, 50, "Cognome");
                commandInsert.Parameters.Add("@cf", System.Data.SqlDbType.NVarChar, 16, "Codice_fiscalse");
                commandInsert.Parameters.Add("@dataNat", System.Data.SqlDbType.Date, 50, "Data_nascita");
                commandInsert.Parameters.Add("@anniServizio", System.Data.SqlDbType.Int, 10, "Anni_servizio");

                //Associo i comandi all'adapter
                adapter.SelectCommand = commandSelect;
                adapter.InsertCommand = commandInsert;

                //Creo il dataset
                DataSet dataset = new DataSet();

                //Provo a connettermi al database
                try
                {
                    //Apro la connessione per salvare i dati in locale
                    connection.Open();

                    //Salvo i dati delle tabella Agente di polizia sul dataset
                    adapter.Fill(dataset, "Agente_di_polizia");

                    //Lavoro in modalità disconnessa
                    //Creo un nuovo record nella tabella agenti
                    DataRow row = dataset.Tables["Agente_di_polizia"].NewRow();

                    //La popolo con i dati inseriti dall'utente
                    row["Nome"] = agente.Nome;
                    row["Cognome"] = agente.Cognome;
                    row["Codice_fiscalse"] = agente.CodiceFiscale;
                    row["Data_nascita"] = agente.DataNascita;
                    row["Anni_servizio"] = agente.AnniDiServizio;

                    //La aggiungo alle altre righe nel dataset
                    dataset.Tables["Agente_di_polizia"].Rows.Add(row);

                    //Mi connetto al database per riportare le modifiche effettute
                    adapter.Update(dataset, "Agente_di_polizia");
                    Console.WriteLine("Agente aggiunto con successo!");

                }
                catch (Exception e)
                {
                    Console.WriteLine("Agnete non aggiunto: " + e.Message);
                }
                finally
                {
                    //Chiudo la connessione anche se va in errore
                    connection.Close();
                }
            }


        }
    }
}
